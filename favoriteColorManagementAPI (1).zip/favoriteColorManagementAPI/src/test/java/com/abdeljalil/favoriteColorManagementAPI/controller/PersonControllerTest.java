package com.abdeljalil.favoriteColorManagementAPI.controller;

import com.abdeljalil.favoriteColorManagementAPI.model.Person;
import com.abdeljalil.favoriteColorManagementAPI.service.PersonService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;


@WebMvcTest(controllers = PersonRESTController.class)
@AutoConfigureMockMvc(addFilters = false)
@ExtendWith(MockitoExtension.class)
public class PersonControllerTest {
    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private PersonService personService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void PersonController_addPerson_ReturnCreated(){
        // Arrange
        Person p = Person.builder()
                .lastName("Labid")
                .firstName("Abdeljalil")
                .zipCode("10965")
                .city("Berlin")
                .color("blau")
                .build();

//        given(personService.addPerson(ArgumentMatchers.any())).willAnswer(invocation ->
//                invocation.getArgument(0));
        // Act
        when(personService.addPerson(ArgumentMatchers.any())).thenReturn(p);

        ResultActions response;
        try {
            response = mockMvc.perform(post("/persons")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(p)));
            // Assert
            response.andExpect(MockMvcResultMatchers.status().isCreated())
                    .andExpect(MockMvcResultMatchers.content().json(objectMapper.writeValueAsString(p)));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }



    }

    @Test
    public void PersonController_findAllPersons_ReturnAllPersons(){

        // Arrange
        Person p = Person.builder()
                .lastName("Labid")
                .firstName("Abdeljalil")
                .zipCode("10965")
                .city("Berlin")
                .color("blau")
                .build();

        Person p2 = Person.builder()
                .lastName("Myzaal")
                .firstName("Ali")
                .zipCode("13407")
                .city("Berlin")
                .color("blau")
                .build();

        Person p3 = Person.builder()
                .lastName("Myzaal")
                .firstName("Omar")
                .zipCode("12345")
                .city("Bulgarien")
                .color("grün")
                .build();


        Person p4 = Person.builder()
                .lastName("Latigue")
                .firstName("Khalil")
                .zipCode("12043")
                .city("Berlin")
                .color("grün")
                .build();

        List<Person> personList = new ArrayList<>();
        personList.add(p);
        personList.add(p2);
        personList.add(p3);
        personList.add(p4);
        // Act
        when(personService.getPersons()).thenReturn(personList);

        ResultActions response;
        try {
            response = mockMvc.perform(get("/persons"));
            // Assert
            response.andExpect(MockMvcResultMatchers.status().isOk())
                    .andExpect(MockMvcResultMatchers.content().json(objectMapper.writeValueAsString(personList)));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void PersonController_findPersonById_ReturnPerson(){
        // Arrange
        Person p = Person.builder()
                .lastName("Labid")
                .firstName("Abdeljalil")
                .zipCode("10965")
                .city("Berlin")
                .color("blau")
                .build();

        Person p2 = Person.builder()
                .lastName("Myzaal")
                .firstName("Ali")
                .zipCode("13407")
                .city("Berlin")
                .color("blau")
                .build();

        Person p3 = Person.builder()
                .lastName("Myzaal")
                .firstName("Omar")
                .zipCode("12345")
                .city("Bulgarien")
                .color("grün")
                .build();


        Person p4 = Person.builder()
                .lastName("Latigue")
                .firstName("Khalil")
                .zipCode("12043")
                .city("Berlin")
                .color("grün")
                .build();

        List<Person> personList = new ArrayList<>();
        personList.add(p);
        personList.add(p2);
        personList.add(p3);
        personList.add(p4);
        // Act
        when(personService.getPersonById(p.getId())).thenReturn(p);

        ResultActions response;
        try {
            response = mockMvc.perform(get("/persons/0"));
            // Assert
            response.andExpect(MockMvcResultMatchers.status().isOk())
                    .andExpect(MockMvcResultMatchers.content().json(objectMapper.writeValueAsString(p)));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void PersonController_getPersonsByColor_ReturnPersonWithSameColor(){
        // Arrange
        Person p = Person.builder()
                .lastName("Labid")
                .firstName("Abdeljalil")
                .zipCode("10965")
                .city("Berlin")
                .color("blau")
                .build();

        Person p2 = Person.builder()
                .lastName("Myzaal")
                .firstName("Ali")
                .zipCode("13407")
                .city("Berlin")
                .color("blau")
                .build();

        Person p3 = Person.builder()
                .lastName("Myzaal")
                .firstName("Omar")
                .zipCode("12345")
                .city("Bulgarien")
                .color("grün")
                .build();


        Person p4 = Person.builder()
                .lastName("Latigue")
                .firstName("Khalil")
                .zipCode("12043")
                .city("Berlin")
                .color("grün")
                .build();

        List<Person> personList = new ArrayList<>();
        personList.add(p);
        personList.add(p2);
        personList.add(p3);
        personList.add(p4);
        // Act
        List<Person> resultList = new ArrayList<>();
        resultList.add(p);
        resultList.add(p2);
        when(personService.getPersonsByColor("blau")).thenReturn(resultList);

        ResultActions response;
        try {
            response = mockMvc.perform(get("/persons/color/blau"));
            // Assert
            response.andExpect(MockMvcResultMatchers.status().isOk())
                    .andExpect(MockMvcResultMatchers.content().json(objectMapper.writeValueAsString(resultList)));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
