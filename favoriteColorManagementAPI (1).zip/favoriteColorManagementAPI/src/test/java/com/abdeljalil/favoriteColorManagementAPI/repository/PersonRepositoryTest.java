package com.abdeljalil.favoriteColorManagementAPI.repository;

import com.abdeljalil.favoriteColorManagementAPI.model.Person;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;

@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class PersonRepositoryTest {

    @Autowired
    private PersonRepository personRepository;


    @Test
    public void PersonRepository_addPerson_ReturnSavedPersons(){
        // Arrange
        Person p = Person.builder()
                .lastName("Labid")
                .firstName("Abdeljalil")
                .zipCode("10965")
                .city("Berlin")
                .color("blau")
                .build();

        // Act
        Person savedPerson = personRepository.save(p);

        // Assert
        Assertions.assertThat(savedPerson).isNotNull();
        Assertions.assertThat(savedPerson.getId()).isGreaterThan(0);
        Assertions.assertThat(savedPerson.getFirstName()).isEqualTo("Abdeljalil");
    }

    @Test
    public void PersonRepository_findAll_ReturnAllSavedPersons(){
        // Arrange
        Person p = Person.builder()
                .lastName("Labid")
                .firstName("Abdeljalil")
                .zipCode("10965")
                .city("Berlin")
                .color("blau")
                .build();

        Person p2 = Person.builder()
                .lastName("Myzaal")
                .firstName("Ali")
                .zipCode("13407")
                .city("Berlin")
                .color("blau")
                .build();

        // Act
        personRepository.save(p);
        personRepository.save(p2);

        List<Person> personsList = personRepository.findAll();

        // Asssert
        Assertions.assertThat(personsList).isNotNull();
        Assertions.assertThat(personsList).isNotEmpty();
        Assertions.assertThat(personsList.size()).isEqualTo(2);
    }

    @Test
    public void PersonRepository_getPersonById_ReturnSavedPersons(){
        // Arrange
        Person p = Person.builder()
                .lastName("Labid")
                .firstName("Abdeljalil")
                .zipCode("10965")
                .city("Berlin")
                .color("blau")
                .build();

        Person p2 = Person.builder()
                .lastName("Myzaal")
                .firstName("Ali")
                .zipCode("13407")
                .city("Berlin")
                .color("blau")
                .build();

        // Act
        personRepository.save(p);
        personRepository.save(p2);

        Person person = personRepository.getReferenceById(p2.getId());

        // Asssert
        Assertions.assertThat(person).isNotNull();
        Assertions.assertThat(person.getFirstName()).isEqualTo("Ali");
        Assertions.assertThat(person.getLastName()).isEqualTo("Myzaal");
        Assertions.assertThat(person.getZipCode()).isEqualTo("13407");
        Assertions.assertThat(person.getCity()).isEqualTo("Berlin");
        Assertions.assertThat(person.getColor()).isEqualTo("blau");
    }

    @Test
    public void PersonRepository_getPersonsByColor_ReturnPersonsWithSameColor(){
        // Arrange
        Person p = Person.builder()
                .lastName("Labid")
                .firstName("Abdeljalil")
                .zipCode("10965")
                .city("Berlin")
                .color("blau")
                .build();

        Person p2 = Person.builder()
                .lastName("Myzaal")
                .firstName("Ali")
                .zipCode("13407")
                .city("Berlin")
                .color("blau")
                .build();

        Person p3 = Person.builder()
                .lastName("Myzaal")
                .firstName("Omar")
                .zipCode("12345")
                .city("Bulgarien")
                .color("grün")
                .build();


        Person p4 = Person.builder()
                .lastName("Latigue")
                .firstName("Khalil")
                .zipCode("12043")
                .city("Berlin")
                .color("grün")
                .build();


        // Act
        personRepository.save(p);
        personRepository.save(p2);
        personRepository.save(p3);
        personRepository.save(p4);
        List<Person> personenList = personRepository.getPersonsByColor("blau");

        // Assert
        Assertions.assertThat(personenList.size()).isEqualTo(2);
        Assertions.assertThat(personenList.get(0).getFirstName()).isEqualTo("Abdeljalil");
        Assertions.assertThat(personenList.get(1).getFirstName()).isEqualTo("Ali");
    }


}
