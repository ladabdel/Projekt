package com.abdeljalil.favoriteColorManagementAPI.service;

import com.abdeljalil.favoriteColorManagementAPI.model.Person;
import com.abdeljalil.favoriteColorManagementAPI.repository.PersonRepository;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class PersonServiceTest {

    @Mock
    private PersonRepository personRepository;

    @InjectMocks
    private PersonServiceImpl personService;

    private CSVParser initCSVData(){
        String mockFile="Müller, Hans, 67742 Lauterecken, 1\n" +
                "Petersen, Peter, 18439 Stralsund, 2\n" +
                "Johnson, Johnny, 88888 made up, 3\n" +
                "Millenium, Milly, 77777 made up too, 4\n" +
                "Müller, Jonas, 32323 Hansstadt, 5\n" +
                "Fujitsu, Tastatur, 42342 Japan, 6\n" +
                "Andersson, Anders, 32132 Schweden - ☀, 2\n" +
                "Bart, Bertram, \n" +
                "12313 Wasweißich, 1 \n" +
                "Gerber, Gerda, 76535 Woanders, 3 \n" +
                "Klaussen, Klaus, 43246 Hierach, 2";
        Reader reader = new StringReader(mockFile);
        CSVParser csvParser;
        try {
            csvParser = new CSVParser(reader, CSVFormat.DEFAULT);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return csvParser;
    }

    @Test
    public void PersonService_transferCSVtoModelData_ReturnPersonList(){
        // Arrange
        CSVParser csvParser =initCSVData();

        // Act
        personService.transferCSVdataToModelData(csvParser);
        Assertions.assertThat(personService.getPersons().size()).isEqualTo(10);
    }

    @Test
    public void PersonService_findAllPersons_ReturnPersonList(){
        // Arrange
        personService.setDataSource(1); // datasource - database
        Person p = Person.builder()
                .lastName("Labid")
                .firstName("Abdeljalil")
                .zipCode("10965")
                .city("Berlin")
                .color("blau")
                .build();

        Person p2 = Person.builder()
                .lastName("Myzaal")
                .firstName("Ali")
                .zipCode("13407")
                .city("Berlin")
                .color("blau")
                .build();

        Person p3 = Person.builder()
                .lastName("Myzaal")
                .firstName("Omar")
                .zipCode("12345")
                .city("Bulgarien")
                .color("grün")
                .build();


        Person p4 = Person.builder()
                .lastName("Latigue")
                .firstName("Khalil")
                .zipCode("12043")
                .city("Berlin")
                .color("grün")
                .build();

        List<Person> dbList = new ArrayList<>();
        dbList.add(p);
        dbList.add(p2);
        dbList.add(p3);
        dbList.add(p4);

        // Act
        when(personRepository.findAll()).thenReturn(dbList);

        // Assert
        Assertions.assertThat(personService.getPersons().size()).isEqualTo(4);
    }



    @Test
    public void PersonService_getPersonByIdFromCSV_ReturnPerson(){

        // Arrange
        CSVParser csvParser =initCSVData();
        personService.transferCSVdataToModelData(csvParser);

        // Act
        Person person = personService.getPersonById(0);

        // Assert
        Assertions.assertThat(person).isNotNull();
        Assertions.assertThat(person.getLastName()).isEqualTo("Müller");
        Assertions.assertThat(person.getFirstName()).isEqualTo("Hans");
    }

    @Test
    public void PersonService_getPersonById_ReturnPerson(){

        // Arrange
        personService.setDataSource(1); // datasource - database
        Person p = Person.builder()
                .lastName("Labid")
                .firstName("Abdeljalil")
                .zipCode("10965")
                .city("Berlin")
                .color("blau")
                .build();

        Person p2 = Person.builder()
                .lastName("Myzaal")
                .firstName("Ali")
                .zipCode("13407")
                .city("Berlin")
                .color("blau")
                .build();

        Person p3 = Person.builder()
                .lastName("Myzaal")
                .firstName("Omar")
                .zipCode("12345")
                .city("Bulgarien")
                .color("grün")
                .build();


        Person p4 = Person.builder()
                .lastName("Latigue")
                .firstName("Khalil")
                .zipCode("12043")
                .city("Berlin")
                .color("grün")
                .build();

        List<Person> dbList = new ArrayList<>();
        dbList.add(p);
        dbList.add(p2);
        dbList.add(p3);
        dbList.add(p4);

        // Act
        when(personRepository.getReferenceById(0)).thenReturn(p);
        Person person = personService.getPersonById(0);

        // Assert
        Assertions.assertThat(person).isNotNull();
        Assertions.assertThat(person.getLastName()).isEqualTo("Labid");
        Assertions.assertThat(person.getFirstName()).isEqualTo("Abdeljalil");
    }

    @Test
    public void PersonService_getPersonsByColorFromCSV_ReturnPersonsWithSameColor(){
        // Arrange
        CSVParser csvParser =initCSVData();
        personService.transferCSVdataToModelData(csvParser);

        // Act
        List<Person> personList = personService.getPersonsByColor("blau");

        // Assert
        Assertions.assertThat(personList).isNotNull();
        Assertions.assertThat(personList.size()).isEqualTo(2);
    }

    @Test
    public void PersonService_getPersonsByColor_ReturnPersonsWithSameColor(){
        // Arrange
        personService.setDataSource(1); // datasource - database
        Person p = Person.builder()
                .lastName("Labid")
                .firstName("Abdeljalil")
                .zipCode("10965")
                .city("Berlin")
                .color("blau")
                .build();

        Person p2 = Person.builder()
                .lastName("Myzaal")
                .firstName("Ali")
                .zipCode("13407")
                .city("Berlin")
                .color("blau")
                .build();


        List<Person> dbList = new ArrayList<>();
        dbList.add(p);
        dbList.add(p2);

        // Act
        when(personRepository.getPersonsByColor("blau")).thenReturn(dbList);
        List<Person> personList = personService.getPersonsByColor("blau");

        // Assert
        Assertions.assertThat(personList).isNotNull();
        Assertions.assertThat(personList.size()).isEqualTo(2);
        Assertions.assertThat(personList.get(0).getFirstName()).isEqualTo("Abdeljalil");
    }

}
