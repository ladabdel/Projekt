package com.abdeljalil.favoriteColorManagementAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FavoriteColorManagementApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
