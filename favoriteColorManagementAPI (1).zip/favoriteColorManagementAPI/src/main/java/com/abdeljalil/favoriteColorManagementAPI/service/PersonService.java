package com.abdeljalil.favoriteColorManagementAPI.service;

import com.abdeljalil.favoriteColorManagementAPI.model.Person;

import java.io.IOException;
import java.util.List;

public interface PersonService {
    

    List<Person> getPersons();

    Person getPersonById(int id);

    List<Person> getPersonsByColor(String color);

    Person addPerson(Person person);

}
