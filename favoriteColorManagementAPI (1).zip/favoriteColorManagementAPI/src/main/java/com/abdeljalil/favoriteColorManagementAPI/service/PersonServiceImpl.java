package com.abdeljalil.favoriteColorManagementAPI.service;

import com.abdeljalil.favoriteColorManagementAPI.model.Person;
import com.abdeljalil.favoriteColorManagementAPI.repository.PersonRepository;
import jakarta.annotation.PostConstruct;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class PersonServiceImpl implements PersonService{


    public ResourceLoader resourceLoader;
    private List<Person> CSVpersonList;
    private PersonRepository personRepository;
    private int dataSource;
    private String csvResourcePath = "";

    @Autowired
    public PersonServiceImpl(ResourceLoader resourceLoader, PersonRepository personRepository) {
        this.resourceLoader = resourceLoader;
        this.personRepository = personRepository;
        this.CSVpersonList = new ArrayList<>();
        csvResourcePath = "";
    }

    @PostConstruct
    private void init(){
        // checking if csv exists - if yes it becomes the data source
        if (fileExists()){
            readCSVData();
            dataSource=0;
            // if no csv exists - databasa becomes the data source
        }else{
            dataSource=1;   // using database instead of csv as data source
        }
        System.out.println("Data-source: " + (dataSource==0 ? "csv" : "database") );
    }



    // check for a csv in the target/classes/files directory with an ...input.csv format - to use it as data-source
    private boolean fileExists(){
        String regex = "(.*)input.csv";
        try {
            File filesDirectory = resourceLoader.getResource("classpath:files").getFile();
            for(File file : filesDirectory.listFiles()){
                if(file.getName().matches(regex)){
                    csvResourcePath = "classpath:files/"+file.getName();
                    return true;
                }
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return false;
    }


    // reading the CSV- File
    public void readCSVData(){

        try (
            Reader reader = Files.newBufferedReader(resourceLoader.getResource(csvResourcePath).getFile().toPath());
            CSVParser csvParser = new CSVParser(reader, CSVFormat.EXCEL);
            //System.out.println(resourceLoader.getResource("classpath:static/sample-input.csv").getFile().getAbsolutePath());
        ) {
            transferCSVdataToModelData(csvParser);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    // parsing the CSV - File and saving the data in the CSVPersonList
    public void transferCSVdataToModelData2(CSVParser csvParser){
        // put all elements in a List and trim all whitespaces from the strings
        List<String> personElements = new ArrayList<>();
        int i=0;
        for (CSVRecord csvRecord : csvParser) {
            for (Iterator<String> it = csvRecord.iterator(); it.hasNext(); ) {
                String record = it.next().trim();
                System.out.println(record);
                if(!record.equals("")) {
                    personElements.add(record);
                    i++;
                    if(i==4){
                        // store all elements of a Person that we need to create the Person Object
                        Person tempPerson = new Person();
                        tempPerson.setId((CSVpersonList.size()+1));
                        tempPerson.setLastName(personElements.get(0));
                        tempPerson.setFirstName(personElements.get(1));
//                        tempPerson.setAddress(personElements.get(2));
                        tempPerson.setColor(translateColor(Integer.parseInt(personElements.get(3))));
                        CSVpersonList.add(tempPerson);
                        personElements.clear();
                        i=0;
                    }
                }
            }
        }
    }

    // parsing the CSV - File and saving the data in the CSVPersonList
    public void transferCSVdataToModelData(CSVParser csvParser){
        // put all elements in a List and trim all whitespaces from the strings
        List<String> personElements = new ArrayList<>();
        for (CSVRecord csvRecord : csvParser) {
            for (int i=0;i<csvRecord.size();i++){
                String temp = csvRecord.get(i).trim();

                // check for empty string
                if(temp !=""){
                    personElements.add(temp);
                }

                if (personElements.size() == 4){
                    // store all elements of a Person that we need to create the Person Object
                    Person tempPerson = new Person();
                    tempPerson.setId(CSVpersonList.size());
                    tempPerson.setLastName(personElements.get(0));
                    tempPerson.setFirstName(personElements.get(1));
                    String[] zipCity = personElements.get(2).split(" ",2);
                    tempPerson.setZipCode(zipCity[0]);
                    tempPerson.setCity(zipCity[1]);
                    tempPerson.setColor(translateColor(Integer.parseInt(personElements.get(3))));
                    CSVpersonList.add(tempPerson);
                    personElements.clear();
                }
            }
        }
    }

    // helper method to translate colorId to color-string
    private String translateColor(int colorId){
        String color;
        switch (colorId){
            case 1:
                color = "blau";
                break;
            case 2:
                color = "grün";
                break;
            case 3:
                color = "violett";
                break;
            case 4:
                color = "rot";
                break;
            case 5:
                color = "gelb";
                break;
            case 6:
                color = "türkis";
                break;
            default:
                color = "weiß";
        }
        return color;
    }

    // helper method to translate color-string to color-id
    private int reverseColor(String color){
        int colorID;
        switch (color){
            case "blau":
                colorID = 1;
                break;
            case "grün":
                colorID = 2;
                break;
            case "violett":
                colorID = 3;
                break;
            case "rot":
                colorID = 4;
                break;
            case "gelb":
                colorID = 5;
                break;
            case "türkis":
                colorID = 6;
                break;
            default:
                colorID = 7;
        }
        return colorID;
    }


    @Override
    public List<Person> getPersons() {
        if(dataSource==0){
            return this.CSVpersonList;
        }
        return this.personRepository.findAll();
    }

    @Override
    public Person getPersonById(int id) {
        if(dataSource==0){
            if(id >= this.CSVpersonList.size()){
                throw new RuntimeException("No Person with this Id exists - " + id);
            }
            return this.CSVpersonList.get(id);
        }

        return this.personRepository.findById(id).get();
    }

    @Override
    public List<Person> getPersonsByColor(String color) {
        if(!colorIsValid(color)){
            throw new RuntimeException("Color is not valid - " + color);
        }
        if(dataSource==0){
            List<Person>  result = CSVpersonList.stream().filter(person -> person.getColor().equals(color)).collect(Collectors.toList());
            return result;
        }else{
            return this.personRepository.getPersonsByColor(color);
        }

    }

    // helper method to check validity on the color string
    private boolean colorIsValid(String color) {
        boolean result;
        switch (color){
            case "blau", "grün", "violett", "rot", "gelb","türkis","weiß":
                result = true;
                break;
            default:
                result = false;
        }
        return result;
    }

    @Override
    public Person addPerson(Person person) {
        if(colorIsValid(person.getColor())){
            if(dataSource==0){
                person.setId(CSVpersonList.size());
                CSVpersonList.add(person);
                addPersonToFile(person);
                return person;
            }else{
                return personRepository.save(person);
            }
        }

        throw new RuntimeException("Color is not valid - " + person.getColor());
    }


    // helper method to write a new Person Entry in the csv - file
    private void addPersonToFile(Person person){

        Resource resource = resourceLoader.getResource(csvResourcePath);

        try(
            FileWriter fileWriter = new FileWriter(resource.getFile(),true);
            BufferedWriter writer = new BufferedWriter(fileWriter);
            CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.EXCEL);
        ) {
                System.out.println(resource.getFile().toPath());
                csvPrinter.printRecord(person.getLastName(),person.getFirstName(),person.getZipCode()+" "+person.getCity(),reverseColor(person.getColor()));
                csvPrinter.flush();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public int getDataSource() {
        return dataSource;
    }

    public void setDataSource(int dataSource) {
        this.dataSource = dataSource;
    }
}
