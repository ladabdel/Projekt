package com.abdeljalil.favoriteColorManagementAPI.repository;

import com.abdeljalil.favoriteColorManagementAPI.model.Person;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface PersonRepository extends JpaRepository<Person, Integer> {

    @Query(value = "select p from Person p where p.color = :color")
    List<Person> getPersonsByColor(@Param("color") String color);

}
