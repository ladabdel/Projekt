package com.abdeljalil.favoriteColorManagementAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FavoriteColorManagementApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FavoriteColorManagementApiApplication.class, args);
	}

}
