package com.abdeljalil.favoriteColorManagementAPI.controller;

import com.abdeljalil.favoriteColorManagementAPI.model.Person;
import com.abdeljalil.favoriteColorManagementAPI.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class PersonRESTController {

    @Autowired
    private PersonService personService;



    @GetMapping("/persons")
    public List<Person> getPersons(){
        return personService.getPersons();
    }

    @GetMapping("/persons/{id}")
    public Person getPersonById(@PathVariable int id){

        return personService.getPersonById(id);
    }

    @GetMapping("/persons/color/{color}")
    public List<Person> getPersonsByColor(@PathVariable String color){
        return personService.getPersonsByColor(color);
    }

    @PostMapping("/persons")
    public ResponseEntity<Person> addPerson(@RequestBody Person person){
        return new ResponseEntity<>(personService.addPerson(person), HttpStatus.CREATED);
    }
}
